import React from 'react'

const UserDetail = () => {
  return (
    <div>
      user
    </div>
  )
}

export default UserDetail;
