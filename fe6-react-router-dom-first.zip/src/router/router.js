import { createBrowserRouter } from "react-router";
import App from "../App";
import Home from "../pages/Home";
import Users from "../pages/Users";
import UserDetail from "../pages/UserDetail";

const router = createBrowserRouter([
    { // Зазвичай спочатку описують головний компонент сайту
        path: "/", // Дефолтний шлях коли є компонент App
        Component: App, // Передаємо посилання на головний компонент, на якому будуть рендериться компоненти які є у масиві children (нижче).
        children: [
            {
                index: true, // За замовчуванням компонент Home відмалюється у компоненті <App />, а там вже викливається <Outlet />
                Component: Home,
            },
            {
                path: "/users",
                Component: Users,
            },
            { // Динамічний шлях
                path: "/users/:userId", // назва може бути люба
                Component: UserDetail,
            }
        ]
    },
]);

export default router;